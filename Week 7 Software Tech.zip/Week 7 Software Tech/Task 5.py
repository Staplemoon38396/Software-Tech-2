import time
import random
import string
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt

class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                temp = root.right
                root = None
                return temp
            elif root.right is None:
                temp = root.left
                root = None
                return temp
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        T3 = y.right
        y.right = z
        z.left = T3
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left
        y.left = z
        z.right = T2
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)
        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node
        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)
        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)
        return node

    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)
        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        else:
            return self.search(node.right, name)
RED = 0
BLACK = 1


class RBNode:
    def __init__(self, name, phone, color=RED):
        self.name = name
        self.phone = phone
        self.color = color         
        self.left = None            
        self.right = None
        self.parent = None


class RedBlackTree:

    def __init__(self):
        self.NIL = RBNode(name=None, phone=None, color=BLACK)
        self.NIL.left = self.NIL
        self.NIL.right = self.NIL
        self.NIL.parent = self.NIL
        self.root = self.NIL

    def Left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent
        if x.parent == self.NIL:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    def Right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right != self.NIL:
            y.right.parent = x
        y.parent = x.parent
        if x.parent == self.NIL:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y
        y.right = x
        x.parent = y

    def insert(self, name, phone):
        z = RBNode(name, phone, color=RED)
        z.left = self.NIL
        z.right = self.NIL
        z.parent = self.NIL
        y = self.NIL
        x = self.root
        while x != self.NIL:
            y = x
            if z.name < x.name:
                x = x.left
            elif z.name > x.name:
                x = x.right
            else:
                x.phone = phone
                return
        z.parent = y
        if y == self.NIL:
            self.root = z
        elif z.name < y.name:
            y.left = z
        else:
            y.right = z
        self.insert_fixup(z)

    def insert_fixup(self, z):
        while z.parent.color == RED:
            if z.parent == z.parent.parent.left:
                y = z.parent.parent.right       
                if y.color == RED:             
                    z.parent.color = BLACK
                    y.color = BLACK
                    z.parent.parent.color = RED
                    z = z.parent.parent
                else:
                    if z == z.parent.right:     
                        z = z.parent
                        self.Left_rotate(z)
                    z.parent.color = BLACK     
                    z.parent.parent.color = RED
                    self.Right_rotate(z.parent.parent)
            else:
                y = z.parent.parent.left        
                if y.color == RED:              
                    z.parent.color = BLACK
                    y.color = BLACK
                    z.parent.parent.color = RED
                    z = z.parent.parent
                else:
                    if z == z.parent.left:      
                        z = z.parent
                        self.Right_rotate(z)
                    z.parent.color = BLACK      
                    z.parent.parent.color = RED
                    self.Left_rotate(z.parent.parent)
        self.root.color = BLACK                 

    def search(self, name):
        x = self.root
        while x != self.NIL:
            if name == x.name:
                return x
            elif name < x.name:
                x = x.left
            else:
                x = x.right
        return None  

    def minimum(self, node):
        while node.left != self.NIL:
            node = node.left
        return node

    def transplant(self, u, v):
        if u.parent == self.NIL:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def delete(self, name):
        z = self.root
        while z != self.NIL:
            if name == z.name:
                break
            elif name < z.name:
                z = z.left
            else:
                z = z.right

        if z == self.NIL:
            return
        y = z
        y_original_color = y.color
        if z.left == self.NIL:
            x = z.right
            self.transplant(z, z.right)
        elif z.right == self.NIL:
            x = z.left
            self.transplant(z, z.left)
        else:
            y = self.minimum(z.right)
            y_original_color = y.color
            x = y.right
            if y.parent == z:
                x.parent = y
            else:
                self.transplant(y, y.right)
                y.right = z.right
                y.right.parent = y
            self.transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color
        if y_original_color == BLACK:
            self.delete_fixup(x)

    def delete_fixup(self, x):
        while x != self.root and x.color == BLACK:
            if x == x.parent.left:
                w = x.parent.right              
                if w.color == RED:              
                    w.color = BLACK
                    x.parent.color = RED
                    self.Left_rotate(x.parent)
                    w = x.parent.right
                if w.left.color == BLACK and w.right.color == BLACK:  
                    w.color = RED
                    x = x.parent
                else:
                    if w.right.color == BLACK:  
                        w.left.color = BLACK
                        w.color = RED
                        self.Right_rotate(w)
                        w = x.parent.right
                    w.color = x.parent.color   
                    x.parent.color = BLACK
                    w.right.color = BLACK
                    self.Left_rotate(x.parent)
                    x = self.root
            else:
                w = x.parent.left              
                if w.color == RED:             
                    w.color = BLACK
                    x.parent.color = RED
                    self.Right_rotate(x.parent)
                    w = x.parent.left
                if w.right.color == BLACK and w.left.color == BLACK:  
                    w.color = RED
                    x = x.parent
                else:
                    if w.left.color == BLACK:   
                        w.right.color = BLACK
                        w.color = RED
                        self.Left_rotate(w)
                        w = x.parent.left
                    w.color = x.parent.color   
                    x.parent.color = BLACK
                    w.left.color = BLACK
                    self.Right_rotate(x.parent)
                    x = self.root
        x.color = BLACK

    def visualize(self, ax=None, title="Red-Black Tree"):
        if self.root == self.NIL:
            print("Tree is empty.")
            return
        show = ax is None
        if show:
            fig, ax = plt.subplots(figsize=(12, 6))
        positions = {}
        self.compute_positions(self.root, 0, 0, 1, positions)
        for node, (x, y) in positions.items():
            for child in (node.left, node.right):
                if child != self.NIL and child in positions:
                    cx, cy = positions[child]
                    ax.plot([x, cx], [y, cy], color='gray', linewidth=1, zorder=1)
        for node, (x, y) in positions.items():
            color = '#c0392b' if node.color == RED else '#2c3e50'
            ec = '#e74c3c' if node.color == RED else '#7f8c8d'
            ax.scatter(x, y, s=800, c=color, edgecolors=ec,
                       linewidths=2, zorder=2)
            label = node.name[:6] if node.name else ''
            ax.text(x, y, label, ha='center', va='center',
                    fontsize=6, color='white', fontweight='bold', zorder=3)
        ax.set_title(title, fontsize=12)
        ax.axis('off')
        if show:
            plt.tight_layout()
            plt.show()

    def compute_positions(self, node, depth, pos, spread, positions):
        if node == self.NIL:
            return pos
        left_pos = self.compute_positions(node.left, depth + 1, pos, spread / 2, positions)
        x = left_pos
        positions[node] = (x, -depth)
        right_pos = self.compute_positions(node.right, depth + 1, x + spread, spread / 2, positions)
        return (x + right_pos) / 2 if node.right != self.NIL else x

def benchmark(n=1000, search_fraction=0.5, delete_count=100, verbose=True):
    names = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
    
    bst = BST()
    bst.root = None
    start = time.time()
    for i in range(n):
        bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_insert_time = time.time() - start
    search_names = (
        random.sample(names, int(n * search_fraction)) +
        ['notfoundname'] * int(n * (1 - search_fraction))
    )
    start = time.time()
    found_bst = sum(1 for name in search_names if bst.search(bst.root, name))
    bst_search_time = time.time() - start
    delete_names = random.sample(names, delete_count)
    start = time.time()
    for name in delete_names:
        bst.root = bst.delete(bst.root, name)
    bst_delete_time = time.time() - start

    avl = AVLTree()
    avl.root = None
    start = time.time()
    for i in range(n):
        avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_insert_time = time.time() - start
    start = time.time()
    found_avl = sum(1 for name in search_names if avl.search(avl.root, name))
    avl_search_time = time.time() - start
    start = time.time()
    for name in delete_names:
        avl.root = avl.delete(avl.root, name)
    avl_delete_time = time.time() - start

    rbt = RedBlackTree()
    start = time.time()
    for i in range(n):
        rbt.insert(names[i], phones[i])
    rbt_insert_time = time.time() - start
    start = time.time()
    found_rbt = sum(1 for name in search_names if rbt.search(name))
    rbt_search_time = time.time() - start
    start = time.time()
    for name in delete_names:
        rbt.delete(name)
    rbt_delete_time = time.time() - start

    results = {
        'Insertions':     (bst_insert_time, avl_insert_time, rbt_insert_time),
        'Searches':       (bst_search_time, avl_search_time, rbt_search_time),
        'Deletions':      (bst_delete_time, avl_delete_time, rbt_delete_time),
        'Found In Search': (found_bst, found_avl, found_rbt)
    }
    if verbose:
        print(f"Benchmarking with {n} entries:\n")
        print("Operation        BST Time (sec)   AVL Time (sec)   RBT Time (sec)")
        print("-------------------------------------------------------------------")
        print(f"Insertions:      {bst_insert_time:.6f}       {avl_insert_time:.6f}       {rbt_insert_time:.6f}")
        print(f"Searches:        {bst_search_time:.6f}       {avl_search_time:.6f}       {rbt_search_time:.6f}")
        print(f"Deletions:       {bst_delete_time:.6f}       {avl_delete_time:.6f}       {rbt_delete_time:.6f}")
        print("-------------------------------------------------------------------")
        print(f"Contacts found in search:")
        print(f"  BST: {found_bst} / {len(search_names)}")
        print(f"  AVL: {found_avl} / {len(search_names)}")
        print(f"  RBT: {found_rbt} / {len(search_names)}")

    return results

def run_benchmark_for_sizes(sizes, num_search=100, num_delete=50):
    bst_times = {'insert': [], 'search': [], 'delete': []}
    avl_times = {'insert': [], 'search': [], 'delete': []}
    rbt_times = {'insert': [], 'search': [], 'delete': []}

    for n in sizes:
        names = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
        search_names = random.sample(names, min(num_search, n))
        delete_names = random.sample(names, min(num_delete, n))

        bst = BST()
        start = time.time()
        for i in range(n):
            bst.root = bst.insert(bst.root, names[i], phones[i])
        bst_times['insert'].append(time.time() - start)
        start = time.time()
        for name in search_names:
            bst.search(bst.root, name)
        bst_times['search'].append(time.time() - start)
        start = time.time()
        for name in delete_names:
            bst.root = bst.delete(bst.root, name)
        bst_times['delete'].append(time.time() - start)

        avl = AVLTree()
        start = time.time()
        for i in range(n):
            avl.root = avl.insert(avl.root, names[i], phones[i])
        avl_times['insert'].append(time.time() - start)
        start = time.time()
        for name in search_names:
            avl.search(avl.root, name)
        avl_times['search'].append(time.time() - start)
        start = time.time()
        for name in delete_names:
            avl.root = avl.delete(avl.root, name)
        avl_times['delete'].append(time.time() - start)

        rbt = RedBlackTree()
        start = time.time()
        for i in range(n):
            rbt.insert(names[i], phones[i])
        rbt_times['insert'].append(time.time() - start)
        start = time.time()
        for name in search_names:
            rbt.search(name)
        rbt_times['search'].append(time.time() - start)
        start = time.time()
        for name in delete_names:
            rbt.delete(name)
        rbt_times['delete'].append(time.time() - start)

    plt.figure(figsize=(12, 8))
    plt.subplot(3, 1, 1)
    plt.plot(sizes, bst_times['insert'], label='BST Insert', marker='o')
    plt.plot(sizes, avl_times['insert'], label='AVL Insert', marker='o')
    plt.plot(sizes, rbt_times['insert'], label='RBT Insert', marker='o')
    plt.ylabel('Time (seconds)')
    plt.title('Insertion Time vs Input Size')
    plt.legend()
    plt.subplot(3, 1, 2)
    plt.plot(sizes, bst_times['search'], label='BST Search', marker='o')
    plt.plot(sizes, avl_times['search'], label='AVL Search', marker='o')
    plt.plot(sizes, rbt_times['search'], label='RBT Search', marker='o')
    plt.ylabel('Time (seconds)')
    plt.title('Search Time vs Input Size')
    plt.legend()
    plt.subplot(3, 1, 3)
    plt.plot(sizes, bst_times['delete'], label='BST Delete', marker='o')
    plt.plot(sizes, avl_times['delete'], label='AVL Delete', marker='o')
    plt.plot(sizes, rbt_times['delete'], label='RBT Delete', marker='o')
    plt.xlabel('Number of Nodes')
    plt.ylabel('Time (seconds)')
    plt.title('Deletion Time vs Input Size')
    plt.legend()
    plt.tight_layout()
    plt.show()

def visualize_rbt():
    sample = [
        ("Alice",   "0422756732"),
        ("Bob",     "0462837234"),
        ("Alexander", "0418913748"),
        ("Eleven",   "0439492487"),
        ("Eve",     "0432190854"),
        ("Max",   "0498743479"),
        ("Kye",   "0450931874"),
        ("Adam",   "0408932480"),
        ("Keelan",    "0467636489"),
        ("Alexandra",    "0473249238"),
    ]
    rbt = RedBlackTree()
    for name, phone in sample:
        rbt.insert(name, phone)

    fig, ax = plt.subplots(figsize=(14, 5))
    rbt.visualize(ax=ax, title="Red-Black Tree")
    plt.tight_layout()
    plt.show()

class BenchmarkApp:
    def __init__(self, master):
        self.master = master
        master.title("BST vs AVL vs RBT Benchmark")

        self.label = tk.Label(master, text="Run benchmark with 1000 entries?")
        self.label.pack(pady=5)

        self.run_btn = tk.Button(master, text="Run Benchmark", command=self.run_benchmark)
        self.run_btn.pack(pady=5)
        self.viz_btn = tk.Button(master, text="Visualize Red-Black Tree",command=visualize_rbt)
        self.viz_btn.pack(pady=5)
        self.result_text = tk.Text(master, height=15, width=50)
        self.result_text.pack(pady=10)
        self.tree = ttk.Treeview(master, columns=("Operation", "BST", "AVL", "RBT"),show='headings')
        self.tree.heading("BST", text="BST Time (s)")
        self.tree.heading("AVL", text="AVL Time (s)")
        self.tree.heading("RBT", text="RBT Time (s)")
        self.tree.pack(pady=10)

    def run_benchmark(self):
        self.result_text.delete(1.0, tk.END)
        results = benchmark(verbose=False)

        summary = (
            f"Insertion Time:  BST: {results['Insertions'][0]:.6f}s "f"AVL: {results['Insertions'][1]:.6f}s "f"RBT: {results['Insertions'][2]:.6f}s\n"
            f"Search Time: BST: {results['Searches'][0]:.6f}s"f"AVL: {results['Searches'][1]:.6f}s" f"RBT: {results['Searches'][2]:.6f}s\n"
            f"Deletion Time: BST: {results['Deletions'][0]:.6f}s "f"AVL: {results['Deletions'][1]:.6f}s "f"RBT: {results['Deletions'][2]:.6f}s\n"
            f"Found in Search: BST: {results['Found In Search'][0]} " f"AVL: {results['Found In Search'][1]} "f"RBT: {results['Found In Search'][2]} out of 1000\n"
        )
        self.result_text.insert(tk.END, summary)
        for row in self.tree.get_children():
            self.tree.delete(row)
        for op in ['Insertions', 'Searches', 'Deletions']:
            bst_time, avl_time, rbt_time = results[op]
            self.tree.insert('', tk.END,
                             values=(op, f"{bst_time:.6f}",f"{avl_time:.6f}",f"{rbt_time:.6f}"))
if __name__ == "__main__":
    root = tk.Tk()
    app = BenchmarkApp(root)
    root.mainloop()
    sizes_to_test = [20, 40, 60, 120, 320, 640, 900, 1000]
    run_benchmark_for_sizes(sizes_to_test)