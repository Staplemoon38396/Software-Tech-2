import random
import timeit


# RECURSION
# At its core, recursion involves solving a problem 
# by breaking it down into smaller, more manageable instances of the same problem. 

# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1  # Base case
    else:
        return n + sum_of_natural_numbers(n - 1)  # Recursive case

# Iterative version 
def sum_of_natural_numbers_iteration(n):
    total = 0
    for _ in range(1, n + 1):
        total += _
    return total

# Example usage:
result = sum_of_natural_numbers(5)  
print(f"The sum of the first 5 natural numbers is {result}")
result = sum_of_natural_numbers_iteration(5)  
print(f"The sum of the first 5 natural numbers (iterative) is {result}")


# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
def fibonacci(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fibonacci(n - 1) + fibonacci(n - 2)
    
# Iterative version 
def fibonacci_iteration(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1

    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

# Example usage:

result = fibonacci(5)  
print(f"The 5th Fibonacci number is {result}")

result = fibonacci_iteration(5)  
print(f"The 5th Fibonacci number (iterative) is {result}")


# CHALLENGE: Use recursion to calculate the factorial.
# 
def factorial(n):
    if n == 0 or n == 1:
        return 1  # Base case
    else:
        return n * factorial(n - 1)  # Recursive case
    
def factorial_iteration(n):
    result = 1
    for _ in range(2, n + 1):
        result *= _
    return result

# Example usage:
num = 5
result = factorial(num)
print(f"The factorial of {num} is {result}")

result = factorial_iteration(num)
print(f"The factorial of {num} (iterative) is {result}")


# MINI-PROJECT: MERGE SORT (A real-world sorting algorithm)
# Merge sort is a sorting algorithm which is
# efficient enough to be commonly used in practice.
# The idea of merge sort is to split a list up
# into smaller and smaller pieces until all that
# remains are single element lists. Since single
# element lists are necessarily sorted, this is
# our 'base case', and we can then start to
# reassemble the list in sorted order.


def merge_sort(array):
    if len(array) <= 1:
        return array
    else:
        left_split = array[:len(array)//2] # Integer division
        right_split = array[len(array)//2:]

        left = merge_sort(left_split)
        right = merge_sort(right_split)        

        return merge(left, right)

        
def merge(left, right):
    merged = []

    left_pointer = 0
    right_pointer = 0

    merging = True

    while merging:

        left_element = left[left_pointer]
        right_element = right[right_pointer]

        if left_element < right_element:
            merged.append(left_element)
            left_pointer += 1
        elif right_element < left_element:
            merged.append(right_element)
            right_pointer += 1
        elif right_element == left_element: # Equal items
            merged.append(right_element)
            merged.append(left_element)
            left_pointer += 1
            right_pointer += 1

        if left_pointer >= len(left): # Reached end of left list
            merged.extend(right[right_pointer:])
            merging = False
        elif right_pointer >= len(right): # Reached end of right list
            merged.extend(left[left_pointer:])
            merging = False

    return merged


# ALGORITHMS FOR TESTING MERGE SORT AGAINST INSERTION SORT FOR BENCHMARKING

# INSERTION SORT
def insertion_sort(arr):

    # Traverse through all elements in the list, starting from the second element (index 1)
    for i in range(1, len(arr)):

        # Store the current element to be compared and inserted into the sorted part of the list
        current_element = arr[i]

        # Move elements of the sorted part of the list that are greater than the current element
        # to one position ahead of their current position
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert the current element into its correct position in the sorted part of the list
        arr[j + 1] = current_element

    return arr


#Testing MERGE SORT with INSERTION SORT

# Generate a large random list
large_random_list = [random.randint(1, 1000) for _ in range(2500)]

# Benchmarking Recurisve vs Iterative Fibonacci, Factorial and Natural numbers
# Choose an integer for factorial + sum tests
n = 1

# Benchmarking recursive vs iterative functions
sum_of_natural_numbers_time = timeit.timeit(lambda: sum_of_natural_numbers(n), number=25)
sum_of_natural_numbers_iteration_time = timeit.timeit(lambda: sum_of_natural_numbers_iteration(n), number=25)

factorial_time = timeit.timeit(lambda: factorial(n), number=25)
factorial_iteration_time = timeit.timeit(lambda: factorial_iteration(n), number=25)

fibonacci_time = timeit.timeit(lambda: fibonacci(n), number=25)
fibonacci_iteration_time = timeit.timeit(lambda: fibonacci_iteration(n), number=25)

print("SUM OF NATURAL NUMBERS")
print(f"Recursive: {sum_of_natural_numbers_time:.6f}")
print(f"Iterative: {sum_of_natural_numbers_iteration_time:.6f}")

print("FACTORIAL")
print(f"Recursive: {factorial_time:.6f}")
print(f"Iterative: {factorial_iteration_time:.6f}")

print("FIBONACCI")
print(f"Recursive: {fibonacci_time:.6f}")
print(f"Iterative: {fibonacci_iteration_time:.6f}")


# Compare times
insertion_time = timeit.timeit(lambda: insertion_sort(large_random_list[:]), number=10)
merge_time = timeit.timeit(lambda: merge_sort(large_random_list[:]), number=10)

print(f"Insertion Sort took: {insertion_time:.6f} seconds")
print(f"Merge Sort took: {merge_time:.6f} seconds")



# Merge sort test cases
l = [2, 6, 9, 5, 3, 4, 5, 6, 6, 7,7,100,1,4] # [random.randint(1, 10) for _ in range(10)]
print(l)
print()
sorted = merge_sort(l)
print(sorted)

l = [1]
sorted = merge_sort(l)
print(sorted)

l = [random.randint(1, 25) for n in range(25)] #
sorted = merge_sort(l)
print(sorted[:25])

n = 80
sum = n
while n > 0:
    n -= 1
    sum += n
print(sum)

# Insertion sort test cases
l = [2, 6, 9, 5, 3, 4, 5, 6, 6, 7,7,100,1,4,600,2.5] # [random.randint(1, 10) for _ in range(10)]
print(l)
print()
sorted = insertion_sort(l)
print(sorted)

l = [1]
sorted = insertion_sort(l)
print(sorted)

l = [random.randint(1, 300) for n in range(15)] #
sorted = insertion_sort(l)
print(sorted[:25])







