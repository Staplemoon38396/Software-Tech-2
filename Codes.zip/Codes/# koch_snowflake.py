# koch_snowflake.py
from tkinter import * 

class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake") 

        self.width = 400
        self.height = 400
        self.canvas = Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()

       
        frame1 = Frame(window) 
        frame1.pack()

        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        entry = Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display Koch Snowflake",
               command=self.display).pack(side=LEFT)

        window.mainloop() 

    def display(self):
        self.canvas.delete("line")
        cx = self.width / 2
        side = 200
        h = side * (3 ** 0.5) / 2

        p1 = [cx, self.height / 2 - h / 2]
        p2 = [cx - side / 2, self.height / 2 + h / 2]
        p3 = [cx + side / 2, self.height / 2 + h / 2]

        order = int(self.order.get())
        if order == 0: 
            self.drawLine(p1, p2)
            self.drawLine(p2, p3)
            self.drawLine(p3, p1)
        else:
            self.displayKoch(order, p1, p2)
            self.displayKoch(order, p2, p3)
            self.displayKoch(order, p3, p1)

    def displayKoch(self, order, p1, p2):
        if order == 1: 
            pA = self.dividePoint(p1, p2, 1)
            pB = self.dividePoint(p1, p2, 2)
            pC = [
                (pA[0] + pB[0]) / 2 - (pB[1] - pA[1]) * (3 ** 0.5) / 2,
                (pA[1] + pB[1]) / 2 + (pB[0] - pA[0]) * (3 ** 0.5) / 2
            ]
            self.drawLine(p1, pA)
            self.drawLine(pA, pC)
            self.drawLine(pC, pB)
            self.drawLine(pB, p2)
        else:
            
            pA = self.dividePoint(p1, p2, 1)
            pB = self.dividePoint(p1, p2, 2)
            pC = [
                (pA[0] + pB[0]) / 2 - (pB[1] - pA[1]) * (3 ** 0.5) / 2,
                (pA[1] + pB[1]) / 2 + (pB[0] - pA[0]) * (3 ** 0.5) / 2
            ]

           
            self.displayKoch(order - 1, p1, pA)
            self.displayKoch(order - 1, pA, pC)
            self.displayKoch(order - 1, pC, pB)
            self.displayKoch(order - 1, pB, p2)

    def drawLine(self, p1, p2):
        self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")

   
    def dividePoint(self, p1, p2, part):
        p = 2 * [0]
        p[0] = p1[0] + (p2[0] - p1[0]) * part / 3
        p[1] = p1[1] + (p2[1] - p1[1]) * part / 3
        return p

KochSnowflake() 