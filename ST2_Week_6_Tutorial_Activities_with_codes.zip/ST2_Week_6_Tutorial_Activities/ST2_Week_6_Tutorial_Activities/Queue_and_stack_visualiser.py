import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 80
NODE_HEIGHT = 40
VERTICAL_GAP = 10
CANVAS_WIDTH = 300
CANVAS_HEIGHT = 500


class StackQueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Stack & Queue Visualizer")

        self.stack = []
        self.queue = []

        self.mode = "stack"

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Value:").grid(row=0, column=0)
        self.value_entry = tk.Entry(control_frame, width=10)
        self.value_entry.grid(row=0, column=1)

        self.action_btn = tk.Button(control_frame, text="Push", command=self.handle_action)
        self.action_btn.grid(row=0, column=2, padx=5)

        self.remove_btn = tk.Button(control_frame, text="Pop", command=self.handle_remove)
        self.remove_btn.grid(row=1, column=2, pady=5)

        tk.Button(control_frame, text="Stack Mode", command=self.set_stack_mode).grid(row=0, column=3, padx=10)
        tk.Button(control_frame, text="Queue Mode", command=self.set_queue_mode).grid(row=1, column=3, padx=10)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)
        self.draw_structure()

    def set_stack_mode(self):
        self.mode = "stack"
        self.action_btn.config(text="Push")
        self.remove_btn.config(text="Pop")
        self.status_label.config(text="Switched to STACK mode")
        self.draw_structure()

    def set_queue_mode(self):
        self.mode = "queue"
        self.action_btn.config(text="Enqueue")
        self.remove_btn.config(text="Dequeue")
        self.status_label.config(text="Switched to QUEUE mode")
        self.draw_structure()

    def handle_action(self):
        try:
            val = int(self.value_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer.")
            return

        if self.mode == "stack":
            self.stack.append(val)
            self.status_label.config(text=f"Pushed {val} onto stack")
        else:
            self.queue.append(val)
            self.status_label.config(text=f"Enqueued {val} into queue")

        self.value_entry.delete(0, tk.END)
        self.draw_structure()

    def handle_remove(self):
        if self.mode == "stack":
            if not self.stack:
                messagebox.showinfo("Empty Stack", "Stack is empty.")
                return
            val = self.stack.pop()
            self.status_label.config(text=f"Popped {val} from stack")
        else:
            if not self.queue:
                messagebox.showinfo("Empty Queue", "Queue is empty.")
                return
            val = self.queue.pop(0)
            self.status_label.config(text=f"Dequeued {val} from queue")
        self.draw_structure()

 
    def draw_node(self, x, y, data):
        self.canvas.create_rectangle(x, y, x + NODE_WIDTH, y + NODE_HEIGHT,fill="lightblue", outline="black", width=2)
        self.canvas.create_text(x + NODE_WIDTH / 2, y + NODE_HEIGHT / 2,text=str(data), font=("Arial", 16))

    def draw_structure(self):
        self.canvas.delete("all")

        if self.mode == "stack":
            items = list(reversed(self.stack))
        else:
            items = self.queue
        x = (CANVAS_WIDTH - NODE_WIDTH) // 2
        y = CANVAS_HEIGHT - NODE_HEIGHT - 10
        for val in items:
            self.draw_node(x, y, val)
            y -= NODE_HEIGHT + VERTICAL_GAP
        if items:
            label = "Top" if self.mode == "stack" else "Front"
            self.canvas.create_text(x + NODE_WIDTH + 40,CANVAS_HEIGHT - NODE_HEIGHT - 10,text=label, font=("Arial", 12), fill="red")



if __name__ == "__main__":
    root = tk.Tk()
    app = StackQueueVisualizer(root)
    root.mainloop()




